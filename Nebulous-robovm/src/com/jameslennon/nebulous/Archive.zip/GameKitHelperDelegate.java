package com.jameslennon.nebulous;

import org.robovm.apple.foundation.NSObjectProtocol;
import org.robovm.objc.annotation.Method;

public interface GameKitHelperDelegate extends NSObjectProtocol {

	@Method(selector = "matchStarted")
	public void matchStarted();

	@Method(selector = "matchEnded")
	public void matchEnded();
	
//	@Method(selector="match:didReceiveData:fromPlayer:")
//	public void matchReceivedData();

}
