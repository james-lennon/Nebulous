package com.jameslennon.nebulous;

import org.robovm.apple.foundation.NSData;
import org.robovm.apple.foundation.NSObject;
import org.robovm.objc.annotation.Method;
import org.robovm.objc.annotation.NativeClass;
import org.robovm.rt.bro.annotation.Library;

@Library(Library.INTERNAL)
@NativeClass
public class MultiplayerNetworking extends NSObject implements
		GameKitHelperDelegate {

	@Override
	@Method(selector = "matchStarted")
	public native void matchStarted();

	@Override
	@Method(selector = "matchEnded")
	public native void matchEnded();

//	@Override
//	@Method(selector = "match:didReceiveData:fromPlayer:")
//	public native void matchReceivedData();
	
	@Method(selector="sendData:")
	public native void sendData(NSData data);

}
